const firebaseConfig = {
    apiKey: "AIzaSyDeTe-Jo3xUN02agmTBLAU24jiEaSOCb-A",
    authDomain: "blog-5969a.firebaseapp.com",
    projectId: "blog-5969a",
    storageBucket: "blog-5969a.appspot.com",
    messagingSenderId: "180041785024",
    appId: "1:180041785024:web:2a30fb260b47af7a045725",
    measurementId: "G-D84RP4NSGZ"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  //firebase.analytics();

  const provider = new GoogleAuthProvider();




  




































/*

function register() {

    alert("hi");

    //var name= document.getElementById("name");
    var email = document.getElementById("email");
    var password = document.getElementById("password");
   // console.log(name.value);
    firebase
  .auth()
  .createUserWithEmailAndPassword(email.value, password.value)
  .then((res) => {
    const user = firebase.auth().currentUser;

    
    if (user != null) {
        user.updateProfile({
            displayName: name.value
        }).then(() => {
          
            window.location = 'blogs.html';
        }).catch((error) => {
          console.log(error);
        });
    } else {
      alert("Some error has occured");
    }

  }
}




function login(){

    var email = document.getElementById("email");
    var password = document.getElementById("password");
    
    firebase
      .auth()
      .signInWithEmailAndPassword(email.value, password.value)
      .then((res) => {
       
        window.location = 'blogs.html';
       
      }
      ).catch(function(error) {
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage);
        
      });
    }
    
    function googleSignIn(){
    base_provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(base_provider).then(function(result){
      console.log(result);
      alert("Success..Signed in with google");
      window.location = 'blogs.html';
    }).catch(function(err){
      console.log(err);
      alert("Failed");
    
    });
    }
   */

 function register(){
   // alert("clicked");
 

    var name= document.getElementById("name").value;
     var email=document.getElementById("email").value;
     var password=document.getElementById("password").value;

     firebase.auth().createUserWithEmailAndPassword(email,password)
     .then(function(){

        console.log("hey");

        firebase.firestore().collection("blog").doc(email).set({name,email,password}).then(()=>console.log("document inserted successfullly")).catch((error) => {
            console.log("Error getting documents: ", error);
        });
 /*  .set({
        name,email,password
    })
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    */



      //  window.location="blogs.html";


      location.href = "blogs.html";
        
     })
     .catch(function(error){
         var error_code = error.code;
         var error_message =error.message;
     });

     

     
  }

  const auth=firebase.auth();
  
  function login(){

    var email=document.getElementById("email").value;
     var password=document.getElementById("password").value;

     firebase.auth().signInWithEmailAndPassword(email,password)
     .then(function(){
        // window.location="blogs.html";
        location.href = "blogs.html";
     })
     .catch(function(error){
        var error_code = error.code;
        var error_message =error.message;
        alert(error_message);

     });
     




}

document.getElementById("form").addEventListener("register",(e)=>{
    e.preventDefault();
    
    
});
alert("success");
function getId(id){
    return document.getElementById(id).value;
}


function googleSignIn(){
    base_provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithPopup(base_provider).then(function(result){
      console.log(result);
      alert("Success..Signed in with google");
      location.href = "blogs.html";
    }).catch(function(err){
      console.log(err);
      alert("Failed");
    
    });
    }


 /* if(validate_email(email)==false || validate_password(password)==false)
  {
      alert("email nad password not entered");
      return;
  }

  auth.createUserWithEmailAndPassword(email,password)
  .then(function(){

    var user= auth.currentUser;

    var database_ref = database.ref();

    var user_data = {

        email : email

    }

    database_ref.child('users/' + user.uid ).set(user_data)






    alert("user created")

  })
  .catch(function(error){

    var error_code= error.code;
    var error_message=error.message;

    alert(error_message);

  })
/*
  function validate_email(email){

    expression=/^[^@]+@\w+(\.\w+)+\w$/

    if(expression.test(email)==true){
        return true
    }
    else{
        return false
    }
  }

  function validate_password(password){
      if(password <6)
      {
          return false
      }
      else{
          return true
      }
  }

*/