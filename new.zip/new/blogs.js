function upload(){




}


function logout(){

    firebase.auth().signOut()
    .then(function() {
      // Sign-out successful.
      alert("user signed out");
      location.href="index.html";
    })
    .catch(function(error) {
      // An error happened
    });
}
